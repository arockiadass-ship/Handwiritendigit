# Handwritten-Text-Recognition-CNN

## Download the dataset from https://www.kaggle.com/datasets/sachinpatel21/az-handwritten-alphabets-in-csv-format
